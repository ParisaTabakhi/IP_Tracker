import React from 'react';

const LocationInfo = ({ userLocation }) => {
  return (
    <div>
      <p>Your IP Address: {userLocation.query}</p>
      <p>
        Location: {userLocation.city}, {userLocation.regionName}, {userLocation.country}
      </p>
    </div>
  );
};

export default LocationInfo;
