// Map
import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const Map = ({ userLocation }) => {
  const mapRef = useRef(null);

  useEffect(() => {
    if (!mapRef.current && userLocation) {
      const map = L.map('map').setView([userLocation.lat, userLocation.lon], 15);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
      L.marker([userLocation.lat, userLocation.lon]).addTo(map);
      mapRef.current = map;
    }
  }, [userLocation]);

  return <div id="map" style={{ width: '100%', height: '400px' }}></div>;
};

export default Map;
