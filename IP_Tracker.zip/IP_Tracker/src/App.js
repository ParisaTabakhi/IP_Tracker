// App.js
import React from 'react';
import IPTracker from './IPTracker';

const App = () => {
  return (
    <div>
      <h1>IP Tracker</h1>
      <IPTracker />
    </div>
  );
};

export default App;
