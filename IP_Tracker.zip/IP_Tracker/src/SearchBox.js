import React, { useState } from 'react';
import axios from 'axios';

const SearchBox = ({ onSearch }) => {
  const [searchInput, setSearchInput] = useState('');

  const handleInputChange = (event) => {
    setSearchInput(event.target.value);
  };

  const handleSearch = async () => {
    try {
      const response = await axios.get(`http://ip-api.com/json/${searchInput}`);
      onSearch(response.data);
    } catch (error) {
      onSearch(null, 'Unable to retrieve location');
    }
  };

  return (
    <div>
      <input type="text" value={searchInput} onChange={handleInputChange} placeholder="Enter IP Address or Domain" />
      <button onClick={handleSearch}>Search</button>
    </div>
  );
};

export default SearchBox;
