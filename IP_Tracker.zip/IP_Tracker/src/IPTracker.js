
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Map from './Map';
import LocationInfo from './LocationInfo';
import SearchBox from './SearchBox';

const IPTracker = () => {
  const [userLocation, setUserLocation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentIP, setCurrentIP] = useState(null); 
  useEffect(() => {
    const fetchUserLocation = async () => {
      try {
        const response = await axios.get('http://ip-api.com/json');
        setUserLocation(response.data);
        setCurrentIP(response.data.query); 
        setLoading(false);
      } catch (error) {
        setError('Unable to retrieve your location');
        setLoading(false);
      }
    };

    fetchUserLocation();
  }, []);

  const handleSearch = async (data, errorMessage) => {
    if (errorMessage) {
      setError(errorMessage);
    } else {
      setUserLocation(data);
      setCurrentIP(data.query); 
    }
  };

  return (
    <div>
      <SearchBox onSearch={handleSearch} />
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <div>
          <LocationInfo userLocation={userLocation} />
          <Map userLocation={userLocation} key={currentIP} />
        </div>
      )}
    </div>
  );
};

export default IPTracker;
